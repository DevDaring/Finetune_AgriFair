# P3 blinded agricultural-advice study protocol

## What is ready

- Eight additional pilot questions, two per toggle axis, crossed with two model families and
  two conditions: 32 pilot assessments per rater.
- Forty-eight main questions, 12 per toggle axis, crossed with the same four system cells:
  192 main assessments per rater.
- Cached answers are shown verbatim. Model family, method, seed, automated scores and the
  private assessment mapping are hidden.
- Left/right presentation and assessment order were fixed by the analysis seed before human
  ratings were available.

## Required people

Use two independent agricultural readers. At least one must be a domain specialist able to
check agronomic recommendations. Record qualifications and conflicts in
`rater_qualifications_template.csv`. Do not call a trained non-expert an agricultural expert.

## Sequence

1. Give each rater the rubric and only their own two pilot files.
2. Run the pilot. Discuss rubric ambiguities, not system identities or desired outcomes.
3. Record all wording changes and the freeze date in `rubric_freeze_record_template.json`.
4. Give each rater only their own main CSV. They work independently and must not compare
   answers before submission.
5. Save completed main files as `R1_main_ratings.csv` and `R2_main_ratings.csv` under the
   sibling `completed/` directory. Preserve the independent pre-adjudication files.
6. Validate/import both files from `Codes/` with:
   `python -m Next_Run.advice_audit --import-ratings results_final_audit_20260912/advice/human_study/completed/R1_main_ratings.csv results_final_audit_20260912/advice/human_study/completed/R2_main_ratings.csv`.
   The same command calculates agreement and question-clustered endpoints.
7. Adjudicate disagreements only after the independent files have been frozen and hashed.

Follow institutional requirements for consent, privacy and any required human-participant
review. These materials do not themselves establish ethics approval or rater qualifications.
